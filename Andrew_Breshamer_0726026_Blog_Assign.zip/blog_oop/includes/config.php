<?php

date_default_timezone_set("America/Toronto");

define("DB_HOST", "localhost");
define("DB_USER", "abreshamer");
define("DB_PASSWORD", "6rqdc6rqdc6qrvd6qrvd");
define("DB_NAME", "abreshamerdb");

// Add your blog name below
$config_blogname = "The Best Blog in the Universe";

// Add your name below
$config_author = "Andrew Breshamer";

?>
