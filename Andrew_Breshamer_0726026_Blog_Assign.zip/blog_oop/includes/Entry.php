<?php

class Entry
{

}